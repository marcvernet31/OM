%Tots els casos funcionen amb el nombre d'iteracions de les transparencies
% menys el cas de CGM FR amb RC1
    %   Stopping criterium:
    %       epsG: conv. tolerance
    %       kmax: maxim. iterations
    %   BLS:
    %       iW=0 : ELS; iW=1 : WC; iW=2 : SWC;
    %   Search Direction:
    %       isd=1 : GM; isd=2 : CGM; isd=3 : BFGS; isd=4 : NM; 
    %       isd=5 : MNM-SD; isd=6 : MNM-CMI
    %
    %       icg=1 : FR; icg=2 : PR+;
    %       irc=0 : no restart; irc=1 : RC1; irc=2 : RC2; 
    %  !! H : matriu per quasi-Newton
    %  !! h : hessianaclear;

clear;
f  = @(x) x(1)^2 + x(2)^3 + 3*x(1)*x(2);
g  = @(x) [2*x(1) + 3*x(2) ; 3*x(2)^2 + 3*x(1)];
h  = @(x) [2,3;3,6*x(2)];
x1 = [-2;-1];

 
epsG= 10^-6; kmax= 1500;       
almax= 1; almin= 10^-6; rho=0.5; c1=0.01; c2=0.9; iW= 1; 
isd = 5; icg = 1; irc= 1 ; nu = 0.1;    
delta = 0.1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Optimization
[xk,dk,alk,iWk,betak,Hk,tauk] = om_uo_solve (x1,f,g,h,epsG,kmax,almax,almin,rho,c1,c2,iW,isd,icg,irc,nu,delta);
save('uo_FDM_CE21.mat','f','g','h'  ,'epsG','kmax','almax','almin','rho','c1','c2','iW','isd','icg','irc','nu','delta','xk','dk','alk','iWk','betak','Hk','tauk');

% Optimization's log
xo=[-2.25;1.5]; xylim = []; logfreq = 1;
[la1k,kappak,rk,Mk] = uo_solve_log(x1,f,g,h,epsG,kmax,almax,almin,rho,c1,c2,iW,isd,icg,irc,nu,delta,xk,dk,alk,iWk,betak,Hk, tauk,xo,xylim,logfreq);
fprintf('[uo_FDM_CE21]\n');
